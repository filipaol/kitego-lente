# KITEGO — la Lente automatica

Ogni ora apre, con un browser vero, le pagine delle centraline delle scuole
che hanno detto sì (tabella `stazioni`, tipo `pagina`), aspetta i numeri,
li legge come fa la Lente nell'app e li scrive in `pagina_letture`.
KITEGO li mostra "dal vivo" col nome della scuola.

Regole:
- legge SOLO le righe `stazioni` con tipo `pagina` e `attiva = true`;
- rispetta robots.txt: se una pagina vieta i lettori automatici, non la
  apre e scrive il motivo in `pagina_letture.errore`;
- non salva chiavi, cookie o altro: solo vento, raffica, direzione, ora.

## Messa in opera (una volta)
1. Su GitHub: crea un repository privato `kitego-lente` e carica questi file
   (Add file → Upload files, compresi la cartella `.github`).
2. Settings → Secrets and variables → Actions → New repository secret:
   - `SUPABASE_URL`  (lo stesso di Netlify)
   - `SUPABASE_SERVICE_KEY`  (lo stesso di Netlify)
3. Actions → "Lente automatica KITEGO" → Run workflow. Il primo giro dura
   2-3 minuti. Poi va da solo, ogni ora.

Costo: 0. Il piano gratuito di GitHub Actions basta per un giro ogni ora.
